import React from "react";

export default class Settings extends React.Component {
  render() {
    console.log("settings");
    return (
      <h1>Settings</h1>
    );
  }
}
