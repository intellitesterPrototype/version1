/*Created by HITESH BHATNAGAR on 24-03-2016.*/

/**
 *  Master Performace Testing Component
 *  Will Hold Load And System Performance Data
 *
 */

import React from "react";


export default class TestMangementPage extends React.Component {

    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <h4>Manage Your Tests</h4>
                    <br/>
                    <img class="center-block" src='../images/TestManagement.jpg'/>
                    <br/>
                </div>
            </div>
        );
    }
}
