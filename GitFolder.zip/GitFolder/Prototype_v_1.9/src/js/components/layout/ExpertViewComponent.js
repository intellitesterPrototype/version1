/**
 * Created by HITESH BHATNAGAR on 25-03-2016.
 */
/**
 * Master Expert View Component
 */

import React from "react";
import FunctionalTestingComponent from './FunctionalTestingComponent';
import PerformanceTestingComponent from './PerformanceTestingComponent';
import UserInterfaceTestingComponent from './UserInterfaceTestingComponent';
import SystemIntegrationTestingComponent from './SystemIntegrationTestingComponent';
import LoadTestingComponent from './LoadTestingComponent';

export default class ExpertViewComponent extends React.Component {

    // Default Constructor
    constructor() {
        super();
        this.state = {
            currentlyLoadedComponent: '',
        };
    }
    // Method for Selecting Functional Testing Mode
    onClickSelectFunctionalTesting(){
        this.setState({currentlyLoadedComponent: 'FunctionalTestingComponent'});
    }
    // Method for Selecting Performance Testing Mode
    onClickSelectPerformanceTesting(){
        this.setState({currentlyLoadedComponent: 'PerformanceTestingComponent'});
    }

    // Method for selecting User Interface Testing
    onClickSelectUserInterfaceTesting(){
        this.setState({currentlyLoadedComponent: 'UserInterfaceTestingComponent'});
    }

    // Method for selecting System Integration Testing Component
    onClickSelectSystemIntegrationTesting(){
        this.setState({currentlyLoadedComponent: 'SystemIntegrationTestingComponent'});
    }

    // Method for selecting Load testing component
    onClickSelectLoadTesting(){
        this.setState({currentlyLoadedComponent: 'LoadTestingComponent'});
    }

    // Default Render Method
    render() {
        if(this.state.currentlyLoadedComponent == 'FunctionalTestingComponent'){
            var temp = <FunctionalTestingComponent></FunctionalTestingComponent>
        }else if(this.state.currentlyLoadedComponent == 'PerformanceTestingComponent'){
            var temp = <PerformanceTestingComponent></PerformanceTestingComponent>
        }else if(this.state.currentlyLoadedComponent == 'UserInterfaceTestingComponent'){
            var temp = <UserInterfaceTestingComponent></UserInterfaceTestingComponent>
        }else if(this.state.currentlyLoadedComponent == 'SystemIntegrationTestingComponent'){
            var temp = <SystemIntegrationTestingComponent></SystemIntegrationTestingComponent>
        }else if(this.state.currentlyLoadedComponent == 'LoadTestingComponent'){
            var temp = <LoadTestingComponent></LoadTestingComponent>
        } else{
            var temp = <div>
                <br/>
                <br/>
                <h3>Select Your View</h3>
                <br/>
                <br/>
            </div>
        }
        return (
            <div classname="page-header" frameBorder="15px" >
                <div class="center-block">
                    <h4>Expert View</h4>
                    <button class="btn btn-primary" type="button"
                            onClick={this.onClickSelectFunctionalTesting.bind(this)}>Functional Testing</button>
                    <button class="btn btn-success" type="button"
                            onClick={this.onClickSelectPerformanceTesting.bind(this)}>Performance Testing</button>
                    <button class="btn btn-info" type="button"
                            onClick={this.onClickSelectUserInterfaceTesting.bind(this)}>User Interface Testing</button>
                    <button class="btn btn-warning" type="button"
                            onClick={this.onClickSelectSystemIntegrationTesting.bind(this)}>System Integration Testing</button>
                    <button class="btn btn-danger" type="button"
                            onClick={this.onClickSelectLoadTesting.bind(this)}>Load Testing</button>
                </div>

                {temp}
            </div>
        );
    }
}
