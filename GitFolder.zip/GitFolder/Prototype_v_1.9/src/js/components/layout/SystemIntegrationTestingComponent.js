/*** Created by HITESH BHATNAGAR on 24-03-2016.*/
/**
 * System Integartion Testing Component
 * Your System Integration Reated Information will be kept here
 */

import React from "react";

export default class SystemIntegrationTestingComponent extends React.Component {

    // Default Constructor
    constructor() {
        super();
        this.state = {
            currentlyLoadedComponent: '',
        };
    }

    //Method for analising when the button is clicked
    onAnalyseClick(){
        this.setState({currentlyLoadedComponent: 'SystemIntegrationPage'});
    }

    // Default Render Method
    render() {
        console.log(this.state.currentlyLoadedComponent);
        if(this.state.currentlyLoadedComponent == 'SystemIntegrationPage'){
            var temp = <div>
                <img class="center-block" src='../images/D3022020.gif'/>
            </div>
        }else{
            var temp = <div>
                <div classname="page-header" frameBorder="15px" >
                    <div >
                        <br/>
                        <h4>Enter System Entry Points</h4>
                        <div>
                            <div class="container">
                                <div class="row">
                                    <div class="form_bg">
                                        <form>
                                            <h2 class="text-center">Enter System Details</h2>
                                            <br/>
                                            <div class="form-group">
                                                <input type="email" class="form-control" id="userid" placeholder="Enter DB URL"></input>
                                            </div>
                                            <div class="form-group">
                                                <input type="input" class="form-control" id="pwd" placeholder="ENTER DB USERNAME"></input>
                                            </div>
                                            <div class="form-group">
                                                <input type="input" class="form-control" id="pwd" placeholder="ENTER DB PASSWORD"></input>
                                            </div>
                                            <div class="form-group">
                                                <input type="input" class="form-control" id="pwd" placeholder="ENTER LOG FILE LOCATION"></input>
                                            </div>
                                            <br/>
                                            <div class="align-center">
                                                <button class="btn btn-primary" type="button" onClick={this.onAnalyseClick.bind(this)}>Analyse</button>
                                            </div>
                                            <br/>
                                            <br/>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        }
        return (
            <div>
                {temp}
            </div>
        );
    }
}