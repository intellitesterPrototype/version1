/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */

/**
 * Intellitester Login component For Loading login Page
 */
import React from "react";


export default class IntellitesterLoginComponent extends React.Component {
    // Just login Whenever the button is clicked
    onclick(){
        this.props.updatelogin(true);
    }

    render() {
        var currentLoginState = this.props.currentState;
        return (
            <div>
                <div class="container">
                    <div class="row">
                        <div class="form_bg">
                            <form>
                                <h2 class="text-center">Login Page</h2>
                                <br/>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="userid" placeholder="User id"></input>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" id="pwd" placeholder="Password"></input>
                                </div>
                                <br/>
                                <div class="align-center">
                                    <button class="btn btn-primary" type="button"  onClick={this.onclick.bind(this)}>Login</button>
                                    <button class="btn btn-danger" type="button">Forgot Password</button>
                                </div>
                                <br/>
                                <br/>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
