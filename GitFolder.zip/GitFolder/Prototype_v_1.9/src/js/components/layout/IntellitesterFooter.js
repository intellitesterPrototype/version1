/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */

/**
 *  Footer Component component to render logo and header text
 */

import React from "react";


export default class IntellitesterFooter extends React.Component {
    render() {
        return (
            <footer>
                <div class="row">
                    <div class="col-lg-12">
                        <p>&copy; Intelliteser Intellectual property</p>
                    </div>
                </div>
            </footer>
        );
    }
}
