/**
 * Created by HITESH BHATNAGAR on 25-03-2016.
 */
/**
 * Master Component for Oweners View
 */

import React from "react";

export default class OwnerViewComponent extends React.Component {

    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <h4>Zoom To Look Inside Your System Flow</h4>
                    <br/>
                    <img class="center-block" src='../images/giphy.gif'/>
                    <br/>
                </div>
            </div>
        );
    }
}
