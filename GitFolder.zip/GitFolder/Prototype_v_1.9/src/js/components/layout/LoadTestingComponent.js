/*Created by HITESH BHATNAGAR on 24-03-2016.*/

/**
 *  Master Load Testing Component
 *  Will Hold Load And System Performance Data
 *
 */

import React from "react";


export default class LoadTestingComponent extends React.Component {

    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <h4>Performance Testing Dashboard</h4>
                    <br/>
                    <img class="center-block" src='../images/sine-cosine-unit-circle-animation.gif'/>
                    <br/>
                </div>
            </div>
        );
    }
}
