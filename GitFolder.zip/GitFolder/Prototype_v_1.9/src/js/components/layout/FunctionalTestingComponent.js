/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */

/**
 * Functional Testing Component ViewPoint
 * All the functional Scenarios Will Be Listed Here
 */

import React from "react";


export default class FunctionalTestingComponent extends React.Component {

    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <br/>
                    <h4>Functional Test Cases Identified :</h4>
                    <div class="container">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Sr No</th>
                                <th>Test Steps</th>
                                <th>Expected Results</th>
                                <th>Actual Results</th>
                                <th>Replay Scenario</th>
                                <th>Save</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>1</td>
                                <td>
                                    Step -1 Enter valid user Name value in username Input Box.
                                    <br/>
                                    Step -2 Enter valid password value in password Input Box.
                                    <br/>
                                    Step -3 Click the Go Button.
                                </td>
                                <td>
                                    <input type="email" class="form-control" id="userid" placeholder="Enter Expected Results"></input>
                                </td>
                                <td>
                                    Step -1 User is allowed to enter valid username value in username Input Box.
                                    <br/>
                                    Step -2 User is allowed to enter valid username value in username Input Box.
                                    <br/>
                                    Step -3 Once the Go button is pressed page changed from "RediffLoginPage" to "RediffInboxPage"
                                </td>
                                <td><button class="btn btn-link" type="button">Play Again</button></td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>
                                    Step -1 Enter invalid user Name value in username Input Box.
                                    <br/>
                                    Step -2 Enter valid password value in password Input Box.
                                    <br/>
                                    Step -3 Click the Go Button.
                                </td>
                                <td>
                                    <input type="email" class="form-control" id="userid" placeholder="Enter Expected Results"></input>
                                </td>
                                <td>
                                    Step -1 User is allowed to enter invalid username value in username Input Box.
                                    <br/>
                                    Step -2 User is allowed to enter valid username value in username Input Box.
                                    <br/>
                                    Step -3 Once the Go button is pressed aleart message is displayed
                                </td>
                                <td><button class="btn btn-link" type="button">Play Again</button></td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>
                                    Step -1 Enter valid user Name value in username Input Box.
                                    <br/>
                                    Step -2 Enter invalid password value in password Input Box.
                                    <br/>
                                    Step -3 Click the Go Button.
                                </td>
                                <td>
                                    <input type="email" class="form-control" id="userid" placeholder="Enter Expected Results"></input>
                                </td>
                                <td>
                                    Step -1 User is allowed to enter valid username value in username Input Box.
                                    <br/>
                                    Step -2 User is allowed to enter invalid username value in username Input Box.
                                    <br/>
                                    Step -3 Once the Go button is pressed aleart message is displayed
                                </td>
                                <td><button class="btn btn-link" type="button">Play Again</button></td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>
                                    Step -1 Enter invalid user Name value in username Input Box.
                                    <br/>
                                    Step -2 Enter invalid password value in password Input Box.
                                    <br/>
                                    Step -3 Click the Go Button.
                                </td>
                                <td>
                                    <input type="email" class="form-control" id="userid" placeholder="Enter Expected Results"></input>
                                </td>
                                <td>
                                    Step -1 User is allowed to enter invalid username value in username Input Box.
                                    <br/>
                                    Step -2 User is allowed to enter invalid username value in username Input Box.
                                    <br/>
                                    Step -3 Once the Go button is pressed aleart message is displayed
                                </td>
                                <td><button class="btn btn-link" type="button">Play Again</button></td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <br/>
                </div>
            </div>
        );
    }
}