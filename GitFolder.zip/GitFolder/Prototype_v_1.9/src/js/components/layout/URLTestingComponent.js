/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */

/**
 * Component after the successfull login happens
 */
import React from "react";

export default class URLTestingComponent extends React.Component {
    // Default Constructor
    constructor() {
        super();
        this.state = {
            urlValue: "",
        };
    }

    // Button for Opening URL Test View
    onClickOpenBrowser(){
        var urlValue = "https://" + this.state.urlValue;
        window.open(urlValue);
    }

    // Button for System Analysis
    onClickAnalyseSystem(e){
        var pageComponentValue = 'SystemAnalysisPage';
        this.props.changeCurrentPage(pageComponentValue);
    }

    // Button for Test Management
    onClickManageTest(e){
        var pageComponentValue = 'TestManagement';
        this.props.changeCurrentPage(pageComponentValue);
    }

    // Button for handling Change in URL
    changeUrl(e) {
        var value = e.target.value;
        this.setState({urlValue: value});
    }
    render() {
        return (
            <div class="container">
                <div class="row">
                <form class="form-search" method="get" id="s" action="/">
                    <div class="align-center">
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <input type="text" class="form-control" name="s"
                               placeholder="Enter Application URL" value={this.props.urlValue}
                               onChange={this.changeUrl.bind(this)}></input>
                        <br/>
                        <br/>
                        <br/>
                        <div>
                            <button class="btn btn-success" style={{float:'center'}} type="button"
                                    onClick={this.onClickOpenBrowser.bind(this)}>Start Testing</button>
                            <button class="btn btn-primary" style={{float:'center'}} type="button"
                                    onClick={this.onClickAnalyseSystem.bind(this)}>Analyise System</button>
                            <button class="btn btn-warning" style={{float:'center'}} type="button"
                                    onClick={this.onClickManageTest.bind(this)}>Test Management</button>
                        </div>
                        <br/>
                        <br/>
                    </div>
                </form>
                </div>
            </div>
        );
    }
}
