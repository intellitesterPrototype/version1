/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */
/**
 * Basic Footer Component 
 * To be displayed on every page
 */
import React from "react";


export default class Footer extends React.Component {
  render() {
    return (
      <footer>
        <div class="row">
          <div class="col-lg-12">
            <p>&copy; Intelliteser Intellectual property</p>
          </div>
        </div>
      </footer>
    );
  }
}
