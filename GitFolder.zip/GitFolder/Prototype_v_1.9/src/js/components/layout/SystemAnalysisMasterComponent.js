/**
 * Created by HITESH BHATNAGAR on 25-03-2016.
 */
/**
 * Master Component for system Analysis layout
 * 
 */

import React from "react";
import ExpertViewComponent from './ExpertViewComponent'
import OwnerViewComponent from './OwnerViewComponent'


export default class SystemAnalysisMasterComponent extends React.Component {
    // Default Constructor
    constructor() {
        super();
        this.state = {
            currenlyLoadedComponent: '',
        };
    }

    // Method for Selecting Expert view
    onExpertViewSelected(){
        this.setState({currenlyLoadedComponent: 'ExpertViewComponent'});
    }

    // Method for selecting the Owners View
    onOwnersViewSelected(){
        this.setState({currenlyLoadedComponent: 'OwnerViewComponent'});
    }

    // Default Render Method
    render() {
        if(this.state.currenlyLoadedComponent == 'ExpertViewComponent'){
            var temp = <div>
                <ExpertViewComponent></ExpertViewComponent>
            </div>
        }else if(this.state.currenlyLoadedComponent == 'OwnerViewComponent'){
            var temp = <div>
                <OwnerViewComponent></OwnerViewComponent>
            </div>
        }else{
            var temp =<div><h4>Select Your View</h4></div>
        }
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <br/>
                    <div class="align-center">
                        <button class="btn btn-primary" type="button"
                                onClick={this.onExpertViewSelected.bind(this)}>ExpertView</button>
                        <button class="btn btn-success" type="button"
                                onClick={this.onOwnersViewSelected.bind(this)}>Owner View</button>
                    </div>
                    {temp}
                </div>
            </div>
        );
    }
}

