/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */
/**
 *  Header component to render logo and header text
 *  Also Containing home button
 */

import React from "react";


export default class Header extends React.Component {
    // User should bind back to the home screen
    // Whenever this home button is pressed
    onclick(){
        this.props.updatelogin(true);
    }
    
    // Default Render Method
    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <h1><img src='../images/logo.jpg'/>
                        <a style={{float:'center-right'}}>Welcome To The Future Of Testing</a>
                        <button class="btn btn-link" style={{float:'right'}} type="button"  
                                onClick={this.onclick.bind(this)}>Home</button>
                    </h1>
                </div>
            </div>
        );
    }
}