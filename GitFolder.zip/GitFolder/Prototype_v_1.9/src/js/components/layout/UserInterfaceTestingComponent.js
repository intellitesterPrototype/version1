/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */

/**
 * User Interface testing Component
 * All the UI releated Test Cases will be listed here
 */

import React from "react";


export default class UserInterfaceTestingComponent extends React.Component {

    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <br/>
                    <h4>UI Test Case Identified :</h4>
                    <div class="container">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Sr No</th>
                                <th>UI Component Name</th>
                                <th>UI Component Type</th>
                                <th>Max Input Size</th>
                                <th>Input Position</th>
                                <th>Save</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>1</td>
                                <td>Username</td>
                                <td>Input Box</td>
                                <td>30 Charectors</td>
                                <td>Center Right</td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Password</td>
                                <td>Input Box</td>
                                <td>30 Charectors</td>
                                <td>Center Right</td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Go</td>
                                <td>button</td>
                                <td>Not Applicable</td>
                                <td>Center Right</td>
                                <td><button class="btn btn-link" type="button">Save</button></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <br/>
                </div>
            </div>
        );
    }
}