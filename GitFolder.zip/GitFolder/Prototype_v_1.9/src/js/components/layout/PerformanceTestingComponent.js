/*Created by HITESH BHATNAGAR on 24-03-2016.*/

/**
 *  Master Performace Testing Component
 *  Will Hold Load And System Performance Data
 *
 */

import React from "react";


export default class PerformanceTestingComponent extends React.Component {

    render() {
        return (
            <div classname="page-header" frameBorder="15px" >
                <div >
                    <h4>Performance Testing Dashboard</h4>
                    <br/>
                    <img class="center-block" src='../images/performanceDashboard.png'/>
                    <br/>
                </div>
            </div>
        );
    }
}