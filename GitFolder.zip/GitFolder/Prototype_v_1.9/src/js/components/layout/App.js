/**
 * Created by HITESH BHATNAGAR on 24-03-2016.
 */

/**
 * Master JS file for maintaining Application State
 * This will be called all the time and the page will be
 * Changed Based on what we want to show
 */
import React from "react";
import Header from "./Header";
import IntellitesterFooter from "./IntellitesterFooter";
import IntellitesterLoginComponent from "./IntellitesterLoginComponent"
import URLTestingComponent from "./URLTestingComponent"
import SystemAnalysisMasterComponent from "./SystemAnalysisMasterComponent"
import TestMangementPage from "./TestMangementPage"

export default class App extends React.Component {
    // Default Constructor
    constructor(props){
        super(props);
        this.state={
            isUserAuthenticated : false,
            currentPage : 'URLTestingComponent'
        }
    }
    // Method for updating Login once the User is validated
    updateLogin(isUserValidated){
        this.setState({isUserAuthenticated : isUserValidated});
        this.setState({currentPage: 'URLTestingComponent'});
    }

    // Change the state of the current page based on need
    changeCurrentPage(currentPageComponent){
        this.setState({currentPage: currentPageComponent});
    }
    // Render Method
    render() {
        if(this.state.isUserAuthenticated){
            // Render According to the page component
            if(this.state.currentPage == 'URLTestingComponent'){
                // Home page : User will always be redirected here
                var temp = <div>
                    <URLTestingComponent changeCurrentPage = {this.changeCurrentPage.bind(this)}></URLTestingComponent>
                </div>
            }else if(this.state.currentPage == 'SystemAnalysisPage'){
                var temp = <div>
                   <SystemAnalysisMasterComponent></SystemAnalysisMasterComponent>
                </div>
            }else if(this.state.currentPage == 'TestManagement'){
                var temp = <div>
                    <TestMangementPage></TestMangementPage>
                </div>
            }
        }else{
            // logic for displaying login page
            var temp = <div>
                <IntellitesterLoginComponent updatelogin = {this.updateLogin.bind(this)}></IntellitesterLoginComponent>
            </div>;
        }
        return (
            // Basic Render Return Method
            <div>
                <Header updatelogin = {this.updateLogin.bind(this)}></Header>
                {temp}
                <IntellitesterFooter></IntellitesterFooter>
            </div>
        );
    }
}